import pandas as pd
import altair as alt
from shiny import App, render, ui, reactive
import requests
import json

# Load the updated collapsed dataset
aggregated_by_hour = pd.read_csv("D:/uchicago/24 fall/data/ps6/dd/top_alerts_map_byhour/top_alerts_map_byhour.csv")

# Extract the hour as an integer
aggregated_by_hour['hour'] = aggregated_by_hour['hour'].str.split(':').str[0].astype(int)

# Prepare the dropdown menu options
unique_combinations = aggregated_by_hour[['updated_type', 'updated_subtype']].drop_duplicates()
unique_combinations['type_subtype'] = unique_combinations['updated_type'] + ' - ' + unique_combinations['updated_subtype']
options = unique_combinations['type_subtype'].tolist()

# Load the GeoJSON data
url = 'https://data.cityofchicago.org/api/geospatial/igwz-8jzy?method=export&format=GeoJSON'
response = requests.get(url)
chicago_geojson = response.json()
geo_data = alt.Data(values=chicago_geojson["features"])

# Define the UI
app_ui = ui.page_fluid(
    ui.h2("Traffic Alerts Dashboard by Hour"),
    ui.input_select(
        id='type_subtype',
        label='Select Type and Subtype:',
        choices=options,
        selected=options[0]
    ),
    ui.input_slider(
        id="hour",
        label="Select Hour:",
        min=0,
        max=23,
        value=12,
        step=1,
        ticks=True,
        animate=True
    ),
    ui.output_ui("alert_plot")
)

# Define the server
def server(input, output, session):
    @reactive.Calc
    def filtered_data():
        selected_type, selected_subtype = input.type_subtype().split(' - ')
        selected_hour = input.hour()

        filtered_df = aggregated_by_hour[
            (aggregated_by_hour['updated_type'] == selected_type) &
            (aggregated_by_hour['updated_subtype'] == selected_subtype) &
            (aggregated_by_hour['hour'] == selected_hour)
        ]

        # Get the top 10 locations
        top_10_bins = filtered_df.sort_values('num_alerts', ascending=False).head(10)

        return top_10_bins

    @output
    @render.ui
    def alert_plot():
        top_10_bins = filtered_data()

        # Create the base map
        base_map = alt.Chart(geo_data).mark_geoshape(
            fill='lightgray',
            stroke='white'
        ).properties(
            width=600,
            height=400
        )

        # Create the scatter plot
        scatter_plot = alt.Chart(top_10_bins).mark_circle(
            color='red',
            opacity=0.7
        ).encode(
            longitude='longitude:Q',
            latitude='latitude:Q',
            size=alt.Size('num_alerts:Q', scale=alt.Scale(range=[100, 1000]), title='Number of Alerts'),
            tooltip=['longitude', 'latitude', 'num_alerts']
        )

        # Adjust coordinate system and layer the charts
        layered_chart = (base_map + scatter_plot).configure_view(
            stroke=None
        ).properties(
            title=f'Top 10 Locations for "{input.type_subtype()}" Alerts at {input.hour():02d}:00 in Chicago'
        ).project(
            type='identity', reflectY=True
        )

        # Serialize the chart to HTML
        chart_html = layered_chart.to_html()

        # Return the HTML content
        return ui.HTML(chart_html)

# Create the app
app = App(app_ui, server)
