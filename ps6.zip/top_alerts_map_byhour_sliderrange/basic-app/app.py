import pandas as pd
import altair as alt
from shiny import App, render, ui, reactive
import requests
import json

# Load the updated collapsed dataset
aggregated_by_hour = pd.read_csv("D:/uchicago/24 fall/data/ps6/dd/top_alerts_map/merged_df.csv")

# Convert 'ts' column to datetime
aggregated_by_hour['ts'] = pd.to_datetime(aggregated_by_hour['ts'])

# Create the 'hour' column by extracting the hour as an integer
aggregated_by_hour['hour'] = aggregated_by_hour['ts'].dt.hour

# Prepare the dropdown menu options
unique_combinations = aggregated_by_hour[['updated_type', 'updated_subtype']].drop_duplicates()
unique_combinations['type_subtype'] = unique_combinations['updated_type'] + ' - ' + unique_combinations['updated_subtype']
options = unique_combinations['type_subtype'].tolist()

# Load the GeoJSON data
url = 'https://data.cityofchicago.org/api/geospatial/igwz-8jzy?method=export&format=GeoJSON'
response = requests.get(url)
chicago_geojson = response.json()
geo_data = alt.Data(values=chicago_geojson["features"])

# Define the UI with sidebar layout
app_ui = ui.page_fluid(
    ui.layout_sidebar(
        ui.sidebar(
            ui.h2("Traffic Alerts Dashboard"),
            ui.input_select(
                id='type_subtype',
                label='Select Type and Subtype:',
                choices=options,
                selected=options[0]
            ),
            ui.input_switch(
                id='switch_button',
                label='Toggle to switch to range of hours',
                value=False
            ),
            # Conditional panel for hour range slider (shown when switch is OFF)
            ui.panel_conditional(
                "input.switch_button == false",
                ui.input_slider(
                    id="hour_range",
                    label="Select Hour Range:",
                    min=0,
                    max=23,
                    value=[6, 9],  # Default range from 6 AM to 9 AM
                    step=1,
                    ticks=True
                )
            ),
            # Conditional panel for single hour slider (shown when switch is ON)
            ui.panel_conditional(
                "input.switch_button == true",
                ui.input_slider(
                    id="hour_single",
                    label="Select Hour:",
                    min=0,
                    max=23,
                    value=6,  # Default to 6 AM
                    step=1,
                    ticks=True
                )
            )
        ),
        ui.output_ui("alert_plot"),
    ),
)

# def server
def server(input, output, session):
    @reactive.Calc
    def selected_hours():
        if input.switch_button():
            # Switch is toggled ON, use single hour
            return input.hour_single()
        else:
            # Switch is toggled OFF, use hour range
            return input.hour_range()

    @reactive.Calc
    def filtered_data():
        selected_type, selected_subtype = input.type_subtype().split(' - ')
        selected_hours_value = selected_hours()

        if input.switch_button():
            # Filter data for a single hour
            filtered_df = aggregated_by_hour[
                (aggregated_by_hour['updated_type'] == selected_type) &
                (aggregated_by_hour['updated_subtype'] == selected_subtype) &
                (aggregated_by_hour['hour'] == selected_hours_value)
            ]
        else:
            # Filter data for a range of hours
            filtered_df = aggregated_by_hour[
                (aggregated_by_hour['updated_type'] == selected_type) &
                (aggregated_by_hour['updated_subtype'] == selected_subtype) &
                (aggregated_by_hour['hour'] >= selected_hours_value[0]) &
                (aggregated_by_hour['hour'] <= selected_hours_value[1])
            ]

        # Aggregate the data over the selected hour(s)
        aggregated_df = filtered_df.groupby(['longitude', 'latitude']).size().reset_index(name='num_alerts')

        # Get the top 10 locations
        top_10_bins = aggregated_df.sort_values('num_alerts', ascending=False).head(10)

        return top_10_bins

    @output
    @render.ui
    def alert_plot():
        top_10_bins = filtered_data()

        if top_10_bins.empty:
            return ui.HTML("<p>No data available for the selected criteria.</p>")
        else:
            # Create the base map
            base_map = alt.Chart(geo_data).mark_geoshape(
                fill='lightgray',
                stroke='white'
            ).properties(
                width=600,
                height=400
            )

            # Create the scatter plot
            scatter_plot = alt.Chart(top_10_bins).mark_circle(
                color='red',
                opacity=0.7
            ).encode(
                longitude='longitude:Q',
                latitude='latitude:Q',
                size=alt.Size('num_alerts:Q', scale=alt.Scale(range=[100, 1000]), title='Number of Alerts'),
                tooltip=['longitude', 'latitude', 'num_alerts']
            )

            # Get the selected hour(s) for the title
            selected_hours_value = selected_hours()
            if input.switch_button():
                # Single hour
                time_str = f'at {selected_hours_value:02d}:00'
            else:
                # Hour range
                time_str = f'from {selected_hours_value[0]:02d}:00 to {selected_hours_value[1]:02d}:00'

            # Adjust coordinate system and layer the charts
            layered_chart = (base_map + scatter_plot).configure_view(
                stroke=None
            ).properties(
                title=f'Top 10 Locations for \"{input.type_subtype()}\" Alerts {time_str} in Chicago'
            ).project(
                type='identity',
                reflectY=True
            )

            # Serialize the chart to HTML
            chart_html = layered_chart.to_html()

            # Return the HTML content
            return ui.HTML(chart_html)

# Create the app
app = App(app_ui, server)
