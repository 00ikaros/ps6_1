# type: ignore
# flake8: noqa
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#| echo: true
#| eval: false

def print_file_contents(file_path):
    """Print contents of a file."""
    try:
        with open(file_path, 'r') as f:
            content = f.read()
            print("```python")
            print(content)
            print("```")
    except FileNotFoundError:
        print("```python")
        print(f"Error: File '{file_path}' not found")
        print("```")
    except Exception as e:
        print("```python") 
        print(f"Error reading file: {e}")
        print("```")

print_file_contents("./top_alerts_map_byhour/app.py") # Change accordingly
#
#
#
#| echo: false

# Import required packages.
import pandas as pd
import altair as alt 
import pandas as pd
from datetime import date
import numpy as np
alt.data_transformers.disable_max_rows() 

import json
#
#
#
#
#
#
#
#
#
file_path_sample = "D:/uchicago/24 fall/data/ps6/waze_data/waze_data_sample.csv"
df_sample = pd.read_csv(file_path_sample)
print(df_sample.head())
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
# load the full data file
file_path = "D:/uchicago/24 fall/data/ps6/waze_data/waze_data.csv"
df = pd.read_csv(file_path, low_memory = False)

# count the number of null and not null
num_null = df.isnull().sum()
num_not_null = df.notnull().sum()

# create a dataframe to store it since the dataset is enormous
dummy_df = pd.DataFrame({
  'null':num_null.values,
  'not_null':num_not_null.values,
  'Variable':num_null.index
})

# melt the dataframe into wide format
melted_df = dummy_df.melt(id_vars = 'Variable', var_name = 'Status', value_name = 'Count')

# create the stacked bar chart
chart_1_2 = alt.Chart(melted_df).mark_bar().encode(
    alt.X('Variable:N', title='Variables'),
    alt.Y('Count:Q', title='Number of Observations'),
    alt.Color('Status:N', title='Status', scale=alt.Scale(domain=['null', 'not_null'], range=["red", "blue"]))
).properties(
    title='Stacked Bar Chart of Null and Not Null Observations for Each Variable',
    width=600,
    height=500
).configure_axis(
    labelAngle=45
).interactive() 

chart_1_2.show()
#
#
#
#
#
#
import numpy as np

# print the unique values for type and subtype
unique_quantity_type = df['type'].unique()
unique_quantity_subtype = df['subtype'].dropna().unique()

print(f"The Unique Values for type are:")
print(unique_quantity_type)

print(f"The Unique Values for subtype are:")
print(unique_quantity_subtype)
#
#
#
# number of types for subtype is na
num_types_nasub = df[df['subtype'].isna()]['type'].unique()
print(f"Number of types that having subtype is NA:")
print(len(num_types_nasub))
#
#
#
unique_type_subtype_comb = df[['type', 'subtype']].drop_duplicates()
print(unique_type_subtype_comb[unique_type_subtype_comb['type'] == 'JAM'])
print(unique_type_subtype_comb[unique_type_subtype_comb['type'] == 'ACCIDENT'])
print(unique_type_subtype_comb[unique_type_subtype_comb['type'] == 'ROAD_CLOSED'])
print(unique_type_subtype_comb[unique_type_subtype_comb['type'] == 'HAZARD'])
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
df['subtype'] = df['subtype'].fillna('Unclassified')
#
#
#
#
#
#
#
crosswalk_df = df[['type', 'subtype']].drop_duplicates().reset_index(drop = True)
crosswalk_df[['updated_type', 'updated_subtype', 'updated_subsubtype']] = ''
print(crosswalk_df.head())
#
#
#
#
#
# the most easiest way i could think of is defining a function
def map_updated_type_subtype(row):
    type_ = row['type']
    subtype= row['subtype']

    if pd.isna(subtype) or subtype.strip == '':
        return pd.Series(['Unclassfied', 'Unclassified', 'Unclassified'])
    
    # for jam
    if type_ == 'JAM':
        if 'HEAVY_TRAFFIC' in subtype:
            return pd.Series(['Jam', 'Heavy traffic', 'Unclassified'])
        elif 'MODERATE_TRAFFIC' in subtype:
            return pd.Series(['Jam', 'Moderate traffic', 'Unclassified'])
        elif 'STAND_STILL_TRAFFIC' in subtype:
            return pd.Series(['Jam', 'Stand-still traffic', 'Unclassified'])
        elif 'LIGHT_TRAFFIC' in subtype:
            return pd.Series(['Jam', 'Light traffic', 'Unclassified'])
        else:
            return pd.Series(['Jam', 'Unclassified', 'Unclassified'])

    # for accident
    elif type_ == 'ACCIDENT':
        if 'MAJOR' in subtype:
            return pd.Series(['Accident', 'Major', 'Unclassified'])
        elif 'MINOR' in subtype:
            return pd.Series(['Accident', 'Minor', 'Unclassified'])
        else:
            return pd.Series(['Accident', 'Unclassified', 'Unclassified'])

    # for road_closed
    elif type_ == 'ROAD_CLOSED':
        if 'EVENT' in subtype:
            return pd.Series(['Road_Closed', 'Event', 'Unclassified'])
        elif 'CONSTRUCTION' in subtype:
            return pd.Series(['Road_Closed', 'Construction', 'Unclassified'])
        elif 'HAZARD' in subtype:
            return pd.Series(['Road_Closed', 'Hazard', 'Unclassified'])
        else:
            return pd.Series(['Road_Closed', 'Unclassified', 'Unclassified'])

    # for hazard
    elif type_ == 'HAZARD':
        if 'WEATHER_HAIL' == subtype:
            return pd.Series(['Hazard', 'Weather', 'Hail'])
        elif 'WEATHER_HEAVY_SNOW' == subtype:
            return pd.Series(['Hazard', 'Weather', 'Heavy snow'])
        elif 'WEATHER_FOG' == subtype:
            return pd.Series(['Hazard', 'Weather', 'Fog'])
        elif 'WEATHER_FLOOD' == subtype:
            return pd.Series(['Hazard', 'Weather', 'Flood'])
        elif 'WEATHER' == subtype:
            return pd.Series(['Hazard', 'Weather', 'Unclassified'])
        elif 'ON_ROAD_LANE_CLOSED' == subtype:
            return pd.Series(['Hazard', 'On road', 'Lane closed'])
        elif 'ON_ROAD_ROAD_KILL' == subtype:
            return pd.Series(['Hazard', 'On road', 'Road kill'])
        elif 'ON_ROAD_TRAFFIC_LIGHT_FAULT' == subtype:
            return pd.Series(['Hazard', 'On road', 'Traffic light fault'])
        elif 'ON_ROAD_CAR_STOPPED' == subtype:
            return pd.Series(['Hazard', 'On road', 'Car stopped'])
        elif 'ON_ROAD_CONSTRUCTION' == subtype:
            return pd.Series(['Hazard', 'On road', 'Construction'])
        elif 'ON_ROAD_EMERGENCY_VEHICLE' == subtype:
            return pd.Series(['Hazard', 'On road', 'Emergency vehicle'])
        elif 'ON_ROAD_ICE' == subtype:
            return pd.Series(['Hazard', 'On road', 'Ice'])
        elif 'ON_ROAD_OBJECT' == subtype:
            return pd.Series(['Hazard', 'On road', 'Object'])
        elif 'ON_ROAD_POT_HOLE' == subtype:
            return pd.Series(['Hazard', 'On road', 'Pot hole'])
        elif 'ON_SHOULDER_MISSING_SIGN' == subtype:
            return pd.Series(['Hazard', 'On shoulder', 'Missing sign'])
        elif 'ON_SHOULDER_ANIMALS' == subtype:
            return pd.Series(['Hazard', 'On shoulder', 'Animals'])
        elif 'ON_SHOULDER_CAR_STOPPED' == subtype:
            return pd.Series(['Hazard', 'On shoulder', 'Car stopped'])
        elif 'ON_SHOULDER' == subtype:
            return pd.Series(['Hazard', 'On shoulder', 'Unclassified'])
        else:
            return pd.Series(['Hazard', 'Unclassified', 'Unclassified'])
    else:
        return pd.Series(['Unclassified', 'Unclassified', 'Unclassified'])


# apply the function into these three cols
crosswalk_df[['updated_type', 'updated_subtype', 'updated_subsubtype']] = crosswalk_df.apply(map_updated_type_subtype, axis = 1)

# fill empty strings with unclassified
crosswalk_df['updated_type'] = crosswalk_df['updated_type'].replace('', 'Unclassified')
crosswalk_df['updated_subtype'] = crosswalk_df['updated_subtype'].replace('', 'Unclassified')
crosswalk_df['updated_subsubtype'] = crosswalk_df['updated_subsubtype'].replace('', 'Unclassified')

# show
print(len(crosswalk_df))
print(crosswalk_df.head())


#
#
#
#
#
# merge with the orignal dataset df
merged_df = df.merge(crosswalk_df, left_on = ['type', 'subtype'], right_on = ['type', 'subtype'], how = 'left')

# num of unclassified for accident
num_unclassified_accident = merged_df[(merged_df['type'] == 'ACCIDENT') & ((merged_df['subtype'] == 'Unclassified') | (merged_df['updated_subtype'] == 'Unclassified'))]

print(len(num_unclassified_accident))
#
#
#
merged_df.to_csv('D:/uchicago/24 fall/data/ps6/dd/top_alerts_map/merged_df.csv', index = False)
#
#
#
#
#
#
# create a key
merged_verification = merged_df[['type', 'subtype', 'updated_type', 'updated_subtype', 'updated_subsubtype']]

# compare
comparison_df = merged_verification.merge(
    crosswalk_df,
    on=['type', 'subtype'],
    how='left',
    suffixes=('_merged', '_crosswalk')
)

# check whether the cols are aligned with both datasets
discrepancies = comparison_df[
    (comparison_df['updated_type_merged'] != comparison_df['updated_type_crosswalk']) |
    (comparison_df['updated_subtype_merged'] != comparison_df['updated_subtype_crosswalk']) |
    (comparison_df['updated_subsubtype_merged'] != comparison_df['updated_subsubtype_crosswalk'])
]

if not discrepancies.empty:
    print("Discrepancies found between merged_df and crosswalk_df:")
    print(discrepancies[['type', 'subtype', 'updated_type_merged', 'updated_subtype', 'updated_subsubtype', 
                         'updated_type_crosswalk', 'updated_subtype_crosswalk', 'updated_subsubtype_crosswalk']])
else:
    print("All updated classifications in merged_df match those in crosswalk_df.")

#
#
#
#
#
#
#
#
import re

# data cleanning function
def extract_data(geo):
    match = re.search(r"POINT\(([-\d.]+) ([-\d.]+)\)", geo)
    if match:
        longitude, latitude = map(float, match.groups())
        return longitude, latitude
    return None, None

# apply the function
merged_df['longitude'], merged_df['latitude'] = zip(*merged_df['geo'].apply(extract_data))

# show
merged_df[['longitude', 'latitude']].head()
#
#
#
#
# drop missing
merged_df = merged_df.dropna(subset=['longitude', 'latitude'])

# bin
merged_df['longitude'] = merged_df['longitude'].apply(lambda x: round(x, 2))
merged_df['latitude'] = merged_df['latitude'].apply(lambda x: round(x, 2))

# calculate the size
result_df = merged_df.groupby(['longitude', 'latitude'])['geo'].size().reset_index(name = 'num_observations')
result = result_df.sort_values('num_observations', ascending = False).reset_index(drop = True)
print(result.head(1))
#
#
#
#
#
# define the chosen type and subtype
chosen_type = 'Accident'
chosen_subtype = 'Unclassified'

# filter the chosen category
filtered_df = merged_df[
    (merged_df['updated_type'] == chosen_type) &
    (merged_df['updated_subtype'] == chosen_subtype)
]

# agg the num_alerts
aggregated_df = filtered_df.groupby(['longitude', 'latitude']).size().reset_index(name = 'num_alters')

# top_10_bins
top_10_bins = aggregated_df.sort_values('num_alters', ascending = False).head(10)
print(top_10_bins)
#
#
#
aggregated_df.to_csv("D:/uchicago/24 fall/data/ps6/dd/top_alerts_map/accident_unclassified_bins.csv", index = False)
#
#
#
#
#
#
print(f"The length of the aggregation dataframe is: ")
print(len(aggregated_df))
#
#
#
#
#
# define the chosen type and subtype
chosen_type = 'Jam'
chosen_subtype = 'Heavy traffic'

# filter the chosen category
filtered_df = merged_df[
    (merged_df['updated_type'] == chosen_type) &
    (merged_df['updated_subtype'] == chosen_subtype)
]

# agg the num_alerts
aggregated_df = filtered_df.groupby(['longitude', 'latitude']).size().reset_index(name='num_alerts')

# top_10_bins
top_10_bins = aggregated_df.sort_values('num_alerts', ascending=False).head(10)

# adjust the min and max values for better visualization
min_lon = top_10_bins['longitude'].min() - 0.1
min_lat = top_10_bins['latitude'].min() - 0.1
max_lon = top_10_bins['longitude'].max() + 0.1
max_lat = top_10_bins['latitude'].max() + 0.1

# create the scatter plot
scatter_plot_3_a = alt.Chart(top_10_bins).mark_circle().encode(
    x=alt.X('longitude:Q', scale=alt.Scale(domain=[min_lon, max_lon]), title='Longitude'),
    y=alt.Y('latitude:Q', scale=alt.Scale(domain=[min_lat, max_lat]), title='Latitude'),
    size=alt.Size('num_alerts:Q', title='Number of Alerts'),
    tooltip=['longitude', 'latitude', 'num_alerts']
).properties(
    width=600,
    height=500,
    title='Top 10 Locations with Highest Number of "Jam - Heavy Traffic" Alerts'
)

# show
scatter_plot_3_a.show()
#
#
#
#
#
#
#
#
import requests
import json

# setting up url
url = 'https://data.cityofchicago.org/api/geospatial/igwz-8jzy?method=export&format=GeoJSON'

# download
response = requests.get(url)

if response.status_code == 200:
    chicago_geojson = response.json()
    print(f"success")
else:
    print(f"falied")
#
#
#
#
#
# MODIFY ACCORDINGLY
file_path = "D:/uchicago/24 fall/data/ps6/dd/top_alerts_map/Boundaries - Neighborhoods.geojson"
#----

with open(file_path) as f:
    chicago_geojson = json.load(f)

geo_data = alt.Data(values=chicago_geojson["features"])
#
#
#
#
#
# although we have prepared the top_10_bins in step 1, we still have to redefined
chosen_type = 'Accident'
chosen_subtype = 'Unclassified'

# filter the chosen category
filtered_df = merged_df[
    (merged_df['updated_type'] == chosen_type) &
    (merged_df['updated_subtype'] == chosen_subtype)
]

# agg the num_alerts
aggregated_df = filtered_df.groupby(['longitude', 'latitude']).size().reset_index(name = 'num_alerts')

# top_10_bins
top_10_bins = aggregated_df.sort_values('num_alerts', ascending = False).head(10)
#
#
#
# create the base map underneath the scatter plot
base_map = alt.Chart(geo_data).mark_geoshape(
    fill = 'lightgray',
    stroke = 'white'
).properties(
    width = 600,
    height = 500
)

# scatter plot
scatter_plot_4 = alt.Chart(top_10_bins).mark_circle(
    color='red',
    opacity=0.8
).encode(
    longitude='longitude:Q',
    latitude='latitude:Q',
    size=alt.Size('num_alerts:Q', scale=alt.Scale(range=[100, 1000]), title='Number of Alerts'),
    tooltip=['longitude', 'latitude', 'num_alerts']
)

# adjust the coordinate system and axes
min_lon = top_10_bins['longitude'].min() - 0.1
min_lat = top_10_bins['latitude'].min() - 0.1
max_lon = top_10_bins['longitude'].max() + 0.1
max_lat = top_10_bins['latitude'].max() + 0.1

# layer the scatter plot on the base map
combined_chart = (base_map + scatter_plot_4).configure_view(
    stroke = None
).properties(
    title = 'Top 10 Locations with Highest Number of "Accident Unclassified" Alerts on Chicago'
).project(
    type = 'identity', reflectY = True
).encode(
    alt.X(scale = alt.Scale(domain = [min_lon, max_lon])),
    alt.Y(scale = alt.Scale(domain = [min_lat, max_lat]))
)

# show
combined_chart.show()
#
#
#
#
#
#
#
#
#
#| eval: false
import pandas as pd
import altair as alt
from shiny import App, render, ui, reactive
import requests
import json

# Read the files
merged_df = pd.read_csv('D:/uchicago/24 fall/data/ps6/dd/top_alerts_map/merged_df.csv')

url = 'https://data.cityofchicago.org/api/geospatial/igwz-8jzy?method=export&format=GeoJSON'
response = requests.get(url)
chicago_geojson = response.json()
geo_data = alt.Data(values=chicago_geojson["features"])

# Prepare the unique combinations
unique_combinations = merged_df[['updated_type', 'updated_subtype']].drop_duplicates()
unique_combinations['type_subtype'] = unique_combinations['updated_type'] + ' - ' + unique_combinations['updated_subtype']
options = unique_combinations['type_subtype'].tolist()

# Define the UI
app_ui = ui.page_fluid(
    ui.h2("Traffic Alerts Dashboard"),
    ui.input_select(
        "type_subtype",
        "Select Type and Subtype:",
        choices=options,
        selected=options[0]
    ),
    ui.output_ui("alert_plot")
)

# Define the server logic
def server(input, output, session):
    @reactive.Calc
    def filtered_data():
        # Split the selected option into type and subtype
        selected_type, selected_subtype = input.type_subtype().split(' - ')

        # Filter the DataFrame
        filtered_df = merged_df[
            (merged_df['updated_type'] == selected_type) &
            (merged_df['updated_subtype'] == selected_subtype)
        ]

        # Aggregate the number of alerts per longitude and latitude bin
        aggregated_df = filtered_df.groupby(['longitude', 'latitude']).size().reset_index(name='num_alerts')

        # Get the top 10 bins with the highest number of alerts
        top_10_bins = aggregated_df.sort_values('num_alerts', ascending=False).head(10)

        return top_10_bins

    @output
    @render.ui
    def alert_plot():
        top_10_bins = filtered_data()

        # Create the base map
        base_map = alt.Chart(geo_data).mark_geoshape(
            fill='lightgray',
            stroke='white'
        ).properties(
            width=600,
            height=400
        )

        # Create the scatter plot
        scatter_plot = alt.Chart(top_10_bins).mark_circle(
            color='red',
            opacity=0.8
        ).encode(
            longitude='longitude:Q',
            latitude='latitude:Q',
            size=alt.Size('num_alerts:Q', scale=alt.Scale(range=[100, 1000]), title='Number of Alerts'),
            tooltip=['longitude', 'latitude', 'num_alerts']
        )

        # Adjust coordinate system and layer the charts
        layered_chart = (base_map + scatter_plot).configure_view(
            stroke=None
        ).properties(
            title=f'Top 10 Locations for "{input.type_subtype()}" Alerts in Chicago'
        ).project(
            type='identity', reflectY=True
        )

        # Serialize the chart to HTML
        chart_html = layered_chart.to_html()

        # Return the HTML content
        return ui.HTML(chart_html)

# Create the app
app = App(app_ui, server)

#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
print(merged_df['ts'])
#
#
#
#
#
#
import datetime as datetime

# convert ts col to datetime
merged_df['ts'] = pd.to_datetime(merged_df['ts'])

# create the hour col by extracing the hour
merged_df['hour'] = merged_df['ts'].dt.strftime('%H:00')

# agg the locations by hour
hour_df = merged_df.groupby(['longitude', 'latitude', 'hour', 'updated_type', 'updated_subtype']).size().reset_index(name = 'num_alerts')

# save the dataset
hour_df.to_csv("D:/uchicago/24 fall/data/ps6/dd/top_alerts_map_byhour/top_alerts_map_byhour.csv", index = False)
#
#
#
print(f"The number of rows for the top alerts map by hours is: {len(hour_df)}")
#
#
#
#
#
alt.renderers.enable('default')

# define the hours
selected_hours = ['12:00', '15:00', '18:00']

# chosen type and subtype
chosen_type = 'Jam'
chosen_subtype = 'Heavy traffic'

# loop over the selected hours to generate the plot
for hour in selected_hours:
    # corrected filtering using '&' and proper parentheses
    filtered_df = merged_df[
        (merged_df['updated_type'] == chosen_type) &
        (merged_df['updated_subtype'] == chosen_subtype) &
        (merged_df['hour'] == hour)
    ]

    # aggregate the data
    aggregated_df = filtered_df.groupby(['longitude', 'latitude']).size().reset_index(name='num_alerts')

    # get the top 10 bins
    top_10_bins = aggregated_df.sort_values('num_alerts', ascending=False).head(10)

    # create the base map using the GeoJSON data
    base_map = alt.Chart(geo_data).mark_geoshape(
        fill='lightgray',
        stroke='white'
    ).properties(
        width=500,
        height=400
    )

    # create the scatter plot
    scatter_plot = alt.Chart(top_10_bins).mark_circle(color='red', opacity=0.5).encode(
        longitude='longitude:Q',
        latitude='latitude:Q',
        size=alt.Size('num_alerts:Q', scale=alt.Scale(range=[100, 1000]), title='Number of Alerts'),
        tooltip=['longitude', 'latitude', 'num_alerts']
    )

    # set up the min and max ranges using the entire dataset for consistency
    min_lon = merged_df['longitude'].min() - 0.1
    min_lat = merged_df['latitude'].min() - 0.1
    max_lon = merged_df['longitude'].max() + 0.1
    max_lat = merged_df['latitude'].max() + 0.1

    # combine the base map and the scatter plot
    layered_chart = (base_map + scatter_plot).configure_view(
        stroke=None
    ).properties(
        title=f'Top 10 "Jam - Heavy Traffic" Locations at {hour}'
    ).project(
        type='identity', reflectY=True
    ).encode(
        alt.X(scale=alt.Scale(domain=[min_lon, max_lon]), title='Longitude'),
        alt.Y(scale=alt.Scale(domain=[min_lat, max_lat]), title='Latitude')
    )

    # display
    layered_chart.display()
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
# Ensure the 'ts' column is a string
merged_df['ts'] = pd.to_datetime(merged_df['ts'], errors='coerce')

# Filter missing or unexpected formats
merged_df = merged_df.dropna(subset=['ts'])

# Extract the hour from the 'ts' column
merged_df['hour'] = merged_df['ts'].dt.hour
#
#
#
chosen_type = 'Jam'
chosen_subtype = 'Heavy traffic'
start_hour = 6
end_hour = 9


filtered_df = merged_df[
    (merged_df['updated_type'] == chosen_type) &
    (merged_df['updated_subtype'] == chosen_subtype) &
    (merged_df['hour'] >= start_hour) & 
    (merged_df['hour'] <= end_hour)
]

# aggreate the data over the selected hours
aggregated_df = filtered_df.groupby(['longitude', 'latitude']).size().reset_index(name = 'num_alerts')

# top_10
top_10_bins = aggregated_df.sort_values('num_alerts', ascending = False).head(10)

# load the geoJSON data
url = 'https://data.cityofchicago.org/api/geospatial/igwz-8jzy?method=export&format=GeoJSON'
response = requests.get(url)
chicago_geojson = response.json()
geo_data = alt.Data(values=chicago_geojson["features"])

# ceate the base map
base_map = alt.Chart(geo_data).mark_geoshape(
    fill='lightgray',
    stroke='white'
).properties(
    width=600,
    height=400
)

# scatter plot
scatter_plot_5 = alt.Chart(top_10_bins).mark_circle(color = 'red', opacity = 0.8).encode(
    longitude='longitude:Q',
    latitude='latitude:Q',
    size = alt.Size('num_alerts:Q', scale = alt.Scale(range = [100, 1000]), title = 'Number of Alerts'),
    tooltip = ['longitude', 'latitude', 'num_alerts']
)

# combine two plots
layered_chart_5 = (base_map + scatter_plot_5).configure_view(
    stroke=None
).properties(
    title=f'Top 10 "Jam - Heavy Traffic" Locations between {start_hour} AM and {end_hour} AM'
).project(
    type='identity', reflectY=True
)

# show
layered_chart_5.show()
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
