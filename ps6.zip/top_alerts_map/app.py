import pandas as pd
import altair as alt
from shiny import App, render, ui, reactive
import requests
import json

# Read the files
merged_df = pd.read_csv('D:/uchicago/24 fall/data/ps6/dd/top_alerts_map/merged_df.csv')

url = 'https://data.cityofchicago.org/api/geospatial/igwz-8jzy?method=export&format=GeoJSON'
response = requests.get(url)
chicago_geojson = response.json()
geo_data = alt.Data(values=chicago_geojson["features"])

# Prepare the unique combinations
unique_combinations = merged_df[['updated_type', 'updated_subtype']].drop_duplicates()
unique_combinations['type_subtype'] = unique_combinations['updated_type'] + ' - ' + unique_combinations['updated_subtype']
options = unique_combinations['type_subtype'].tolist()

# Define the UI
app_ui = ui.page_fluid(
    ui.h2("Traffic Alerts Dashboard"),
    ui.input_select(
        "type_subtype",
        "Select Type and Subtype:",
        choices=options,
        selected=options[0]
    ),
    ui.output_ui("alert_plot")
)

# Define the server logic
def server(input, output, session):
    @reactive.Calc
    def filtered_data():
        # Split the selected option into type and subtype
        selected_type, selected_subtype = input.type_subtype().split(' - ')

        # Filter the DataFrame
        filtered_df = merged_df[
            (merged_df['updated_type'] == selected_type) &
            (merged_df['updated_subtype'] == selected_subtype)
        ]

        # Aggregate the number of alerts per longitude and latitude bin
        aggregated_df = filtered_df.groupby(['longitude', 'latitude']).size().reset_index(name='num_alerts')

        # Get the top 10 bins with the highest number of alerts
        top_10_bins = aggregated_df.sort_values('num_alerts', ascending=False).head(10)

        return top_10_bins

    @output
    @render.ui
    def alert_plot():
        top_10_bins = filtered_data()

        # Create the base map
        base_map = alt.Chart(geo_data).mark_geoshape(
            fill='lightgray',
            stroke='white'
        ).properties(
            width=600,
            height=400
        )

        # Create the scatter plot
        scatter_plot = alt.Chart(top_10_bins).mark_circle(
            color='red',
            opacity=0.8
        ).encode(
            longitude='longitude:Q',
            latitude='latitude:Q',
            size=alt.Size('num_alerts:Q', scale=alt.Scale(range=[100, 1000]), title='Number of Alerts'),
            tooltip=['longitude', 'latitude', 'num_alerts']
        )

        # Adjust coordinate system and layer the charts
        layered_chart = (base_map + scatter_plot).configure_view(
            stroke=None
        ).properties(
            title=f'Top 10 Locations for "{input.type_subtype()}" Alerts in Chicago'
        ).project(
            type='identity', reflectY=True
        )

        # Serialize the chart to HTML
        chart_html = layered_chart.to_html()

        # Return the HTML content
        return ui.HTML(chart_html)

# Create the app
app = App(app_ui, server)
